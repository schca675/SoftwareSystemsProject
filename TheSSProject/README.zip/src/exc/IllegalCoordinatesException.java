package exc;

public class IllegalCoordinatesException extends Exception {
	private static final long serialVersionUID = 1L;

	public String getMessage() {
		return "Congratulation, you got a dummy exception.";
	}
}
